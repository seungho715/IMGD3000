#pragma once

#include "Manager.h"
#include <vector>
#include "Object.h"

// Two-letter acronym for easier access to manager.
#define WM df::WorldManager::getInstance()

namespace df {

	class WorldManager : public df::Manager
	{
	private:
		WorldManager(); //private (a singleton)
		WorldManager(WorldManager const&); //Don't allow copy
		void operator=(WorldManager const&);

		std::vector<Object*> m_updates; //All Objects in world to update
		std::vector<Object*> m_deletions; //All Objects in world to delete
	public:
		//Get the one and only instance of the WorldManager
		static WorldManager& getInstance();

		//StartUp game world(initialize everything to empty)
		//Return 0
		int startUp();

		//Shutdown game world(delete all game World Objects)
		void shutDown();

		//Insert Object into World. Return 0 if ok, else -1
		int insertObject(Object* p_o);

		//Remove Object from world. Return 0 if ok, else -1.
		int removeObject(Object* p_o);

		//Return list of all Objects in the world 
		std::vector<Object*> getAllObjects() const;

		//Return list of all Objects in the world matching type
		std::vector<Object*> objectsofType(std::string type) const;

		//Update World 
		//Delete Objects marked for deletion
		void update();

		//Indicate Object is to be deleted at end of current game loop
		//Return 0 if ok, else -1
		int markForDelete(Object* p_o);


	};

}