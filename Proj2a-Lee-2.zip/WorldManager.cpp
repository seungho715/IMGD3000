#include "WorldManager.h"
#include "Object.h"
#include <vector>
#include <iostream>
#include "Manager.h"

using namespace df;

//Constructor for the WorldManager class 
//Initializes all varialbes and types
WorldManager::WorldManager()
{
	m_updates.clear();
	m_deletions.clear();
	setType("WorldManager");
}

//Making an Instance of WorldManager 
//Singleton Method
WorldManager &WorldManager::getInstance()
{
	static WorldManager single_wm;
	return single_wm;
}

//StartUp WorldManager, but not used for Project 2a
int WorldManager::startUp()
{
	m_updates.clear();
	m_deletions.clear();
	return(Manager::startUp());
}

//ShutDown WorldManager, activates the destructor for Objects
void WorldManager::shutDown()
{
	//Delete All Game Objects
	std::vector<Object*> ol = m_updates;
	std::vector<Object*>::iterator li = ol.begin();
	for (li = ol.begin(); li !=ol.end(); li++)
	{
		delete *li;
	}
	Manager::shutDown();
}

//Inserts Object to the Game while updating
//Uses m_updates for inserting
int WorldManager::insertObject(Object* p_o)
{
	m_updates.push_back(p_o);
	return 1;
}

//Deletes Object to the Game while deleting
//Uses m_deletion for deleting
int WorldManager::removeObject(Object* p_o)
{
	std::vector<Object*> copy = m_updates;
	std::vector<Object*>::iterator li = m_updates.begin();
	for (li = m_updates.begin(); li != m_updates.end(); li++)
	{
		if (p_o == *li)
		{
			m_updates.erase(li);
			return 1;
		}
	}
	return -1;
}

std::vector<Object*> WorldManager::getAllObjects()const
{
	//Returns the updates ObjectList
	return m_updates;
}

std::vector<Object*> WorldManager::objectsofType(std::string type)const
{
	std::vector<Object*> list;
	std::vector<Object*> copy = m_updates;
	std::vector<Object*>::iterator li = copy.begin();
	for (li = copy.begin(); li != copy.end(); li++)
		if ((*li)->getType() == type)
			list.push_back(*li);
	return list;
}

int WorldManager::markForDelete(Object* p_o)
{
	//Object might already have been marked, so only add once.
	std::vector<Object*> ol = m_deletions;
	std::vector<Object*>::iterator li = ol.begin();
	while (li != ol.end())
	{
		if ((*li) == p_o) //will this be a pointer?
		{
			return 0;
		}
		li++;
	}
	//Object not in list, so add. 
	m_deletions.push_back(p_o);
	return -1;
}

void WorldManager::update()
{
	//Delete all marked objects.
	std::vector<Object*> ol = m_deletions;
	std::vector<Object*>::iterator li = ol.begin();
	while (li != ol.end())
	{
		delete *li;
		li++;
	}
	m_deletions.clear();
}
