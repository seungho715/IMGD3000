#pragma once
#include <string>
#include "Vector.h"
#include "Event.h"
namespace df {
	class Object
	{
	private:
		int m_id;
		std::string m_type;
		Vector m_position;
	public:
		//Construct Object. Set default parameters and
		//add to game world(WorldManager)
		Object();

		//Destroy Object. 
		//Remove from game world(WorldManager)
		virtual ~Object();

		//Set Object ID
		void setId(int new_id);

		//Get Object ID
		int getId() const;

		//Set type identifier of object
		void setType(std::string new_type);

		//Get type identifier of object
		std::string getType() const;

		//Set position of Object
		void setPosition(Vector new_pos);

		//Get positin of Object
		Vector getPosition() const;

		//EventHandler
		virtual int eventHandler(Event* p_e);
	};

}