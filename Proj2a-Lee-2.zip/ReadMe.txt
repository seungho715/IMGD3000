ReadMe File - Seungho(Chris) Lee

Platform is Visual Studio 2019. 
All the .h files and .cpp files are located inside the Project 2 folder, which is located in documents/Visual Studio 2019/project2/project 2.
Files: Clock, Manager, LogManager, WorldManager, GameManager, Object, Vector, Event, EventStep, and Implemented libraries(winmm and more).
To compile, you first need to build the project, which will build all the files and .o files that are necessary to run it. Then, it will run
the test, which will either put LogManager messages in the dragonfly file or display on a window screen from Visual Studio. 

In the test.cpp, I performed tests on the basic setters and getters of different classes. Also I test some of the (comparatively) significant 
methods like run, eventhandler, markfordelete, update, and more. For example, I have used both update and markfordelete together to make the 
test methods more efficient. Adding on, I tested if all the functions go in to the test and the time(clock.delta and sleep) works correctly. 