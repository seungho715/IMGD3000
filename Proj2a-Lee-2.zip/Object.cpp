#include "Object.h"
#include <string>
#include <stdio.h>
#include "Vector.h"
#include "WorldManager.h"
#include "EventStep.h"

using namespace df;

Object::Object()
{
	m_id = 0;
	m_type = "undefined";
	Vector m_position;
	//Add self to game world
	WM.insertObject(this);
}

Object::~Object()
{
	//remove self from game world
	WM.removeObject(this);
}

void Object::setId(int new_id)
{
	m_id = new_id;
}

int Object::getId()const
{
	return m_id;
}

void Object::setType(std::string new_type)
{
	m_type = new_type;
}

std::string Object::getType()const
{
	return m_type;
}

void Object::setPosition(Vector new_pos)
{
	m_position = new_pos;
}

Vector Object::getPosition()const
{
	return m_position;
}

int Object::eventHandler(Event* p_e)
{
	if (p_e->getType() == STEP_EVENT)
		return 1;
	else
		return 0;
}

