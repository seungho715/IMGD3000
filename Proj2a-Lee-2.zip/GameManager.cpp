#include "GameManager.h"
#include "LogManager.h"
#include "WorldManager.h"
#include "Clock.h"
#include "Manager.h"
#include <vector>
#include "Event.h"
#include "EventStep.h"
#include <Windows.h>
#include "Object.h"

using namespace df;

GameManager::GameManager()
{
	Manager();
	setType("GameManager");
	game_over = true;
	frame_time = 0;
}

int GameManager::run()
{
	int game_loop_count = 0;
	std::vector<Object*> world_objects;
	Clock clock;
	if (game_over == false)
	{
		LM.writeLog("It works");
	}
	while (game_over == false)
	{
		LM.writeLog("Running the game right now");
		clock.delta();
		//get input

		//update
		std::vector<Object*> all_objects = WM.getAllObjects();
		EventStep es;
		es.setStepCount(game_loop_count);
		std::vector<Object*> ol = all_objects;
		std::vector<Object*>::iterator li = ol.begin();
		while (li != ol.end())
		{
			(*li)->eventHandler(&(Event)es);
			li++;
		}

		//Draw Current Scene to back buffer
		//Swap back buffer to current buffer

		long int loop_time = clock.split();
		Sleep(FRAME_TIME_DEFAULT - loop_time);
		game_loop_count++;
		WM.update();
		if (game_loop_count == 5)
		{
			return 1;
			setGameOver(false);
		}
	}
	return 0;
}

int GameManager::startUp()
{
	GM.getInstance(); //What do I do here after getting an instance 
	if (LM.startUp() == 0)
	{
		game_over = false;
		timeBeginPeriod(1);
	}
	WM.startUp();
	return(Manager::startUp());
}

void GameManager::shutDown()
{
	LM.shutDown();
	setGameOver(true);
	timeEndPeriod(1);
	WM.shutDown();
}

GameManager &GameManager::getInstance()
{
	static GameManager single_gm;
	return single_gm;
}

void GameManager::setGameOver(bool new_game_over)
{
	game_over = new_game_over;
}

bool GameManager::getGameOver()const
{
	return game_over;
}

int GameManager::getFrameTime()const
{
	return frame_time;
}
