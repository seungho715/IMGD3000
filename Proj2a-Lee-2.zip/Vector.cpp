#include "Vector.h"
#include <stdio.h>
#include <math.h>

Vector::Vector()
{
	m_x = 0;
	m_y = 0;
}

Vector::Vector(float x, float y)
{
	m_x = x;
	m_y = y;
}

void Vector::setX(float x)
{
	m_x = x;
}

float Vector::getX()const
{
	return m_x;
}

void Vector::setY(float y)
{
	m_y = y;
}

float Vector::getY()const
{
	return m_y;
}

void Vector::setXY(float x, float y)
{
	Vector(x, y);
}

float Vector::getMagnitude()const
{
	return (sqrt((m_x * m_x) + (m_y + m_y)));
}

void Vector::normalize()
{
	float length = getMagnitude();
	if (length > 0)
	{
		m_x = m_x;
		m_y = m_y;
	}
}

void Vector::scale(float s)
{
	m_x = m_x * s;
	m_y = m_y * s;
}

Vector Vector::operator+(const Vector &other)const
{
	Vector v;
	v.m_x = m_x + other.m_x;
	v.m_y = m_y + other.m_y;
	return v;
}

