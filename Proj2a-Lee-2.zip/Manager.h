#pragma once
#include <string>
namespace df {

	class Manager
	{
	private:
		std::string m_type; //manager type identifier
		bool m_is_started; //True when started successfully

	protected:
		void setType(std::string type);

	public:
		Manager();
		virtual ~Manager();

		//get type identifier of manager
		std::string getType() const;

		//Startup Manager
		//Returns 0 if ok, else negative number
		virtual int startUp();

		//shutdown Manager
		virtual void shutDown();

		//Return true when startUp() was executed ok, else false 
		bool isStarted() const;

	};
} // end of namespace df

