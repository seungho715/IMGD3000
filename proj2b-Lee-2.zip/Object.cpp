#include "Object.h"
#include <string>
#include <stdio.h>
#include "Vector.h"
#include "WorldManager.h"
#include "EventStep.h"
#include "EventMouse.h"
#include "EventCollision.h"
#include "EventKeyBoard.h"
#include "EventOut.h"

using namespace df;

Object::Object()
{
	m_id = 0;
	m_type = "undefined";
	Vector m_position;
	Vector m_direction;
	m_speed = 0;
	m_solidness = Solidness::SPECTRAL;
	m_no_soft = false; 
	//Add self to game world
	WM.insertObject(this);
}

Object::~Object()
{
	//remove self from game world
	WM.removeObject(this);
}

void Object::setId(int new_id)
{
	m_id = new_id;
}

int Object::getId()const
{
	return m_id;
}

void Object::setType(std::string new_type)
{
	m_type = new_type;
}

std::string Object::getType()const
{
	return m_type;
}

void Object::setPosition(Vector new_pos)
{
	m_position = new_pos;
}

Vector Object::getPosition()const
{
	return m_position;
}

int Object::eventHandler(Event* p_e)
{
	if (p_e->getType() == STEP_EVENT)
		return 1;
	else if (p_e->getType() == MSE_EVENT)
		return 1;
	else if (p_e->getType() == KEYBOARD_EVENT)
		return 1;
	else if (p_e->getType() == COLLISION_EVENT)
		return 1;
	else if (p_e->getType() == OUT_EVENT)
		return 1;
	else
		return 0;
}

int Object::getAltitude()const
{
	return m_altitude;
}

int Object::setAltitude(int new_altitude)
{
	m_altitude = new_altitude;
	return 0;
}

Vector Object::getDirection()const
{
	return m_direction;
}

void Object::setDirection(Vector new_direction)
{
	m_direction = new_direction;
}

float Object::getSpeed()const
{
	return m_speed;
}

void Object::setSpeed(float speed)
{
	m_speed = speed;
}

Vector Object::predictPosition()
{
	//Add Velocity to position
	Vector new_pos = Vector(m_position.getX() + getVelocity().getX(), m_position.getY() + getVelocity().getY());

	return new_pos;
}

bool Object::isSolid()const
{
	if (m_solidness == HARD || SOFT)
	{
		return true;
	}
	return false;
}

int Object::setSolidness(Solidness new_solid)
{
	m_solidness = new_solid;
	return 0;
}

Solidness Object::getSolidness()const
{
	return m_solidness;
}

void Object::setVelocity(Vector new_pos)
{
	m_direction.setX(new_pos.getX() / m_speed);
	m_direction.setY(new_pos.getY() / m_speed);
}

Vector Object::getVelocity()const
{
	Vector v = Vector(m_direction.getX() * m_speed, m_direction.getY() * m_speed);
	return v;
}

void Object::setNoSoft(bool new_no_soft)
{
	m_no_soft = new_no_soft;
}

bool Object::getNoSoft()const
{
	return m_no_soft;
}

int Object::draw()
{
	return 0;
}