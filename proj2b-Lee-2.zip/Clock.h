#pragma once
#include <stdio.h>
#include <time.h>
#include <math.h>

	class Clock
	{
	private:
		long int m_previous_time;
	public:
		Clock();
		//Return time elapsed since delta() was last called
		//Resets previous time
		long int delta();

		//Return time elapsed since delta() was last called
		//Does not reset 
		long int split() const;

		//Returns m_previous_time
		//For testing
		long int returnClock();
	};


