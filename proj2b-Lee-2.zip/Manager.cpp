#include "Manager.h"
#include "Event.h"
#include "WorldManager.h"
#include <stdio.h>
#include <string>
using namespace std;


	df::Manager::Manager()
	{
		m_type = "";
		m_is_started = false;
	}

	df::Manager::~Manager()
	{
		
	}


	int df::Manager::startUp()
	{
		m_is_started = true;
		if (m_is_started == true)
		{
			return 0;
		}
		else
			return -1;
	}

	void df::Manager::shutDown()
	{
		m_is_started = false;
	}

	bool df::Manager::isStarted()const
	{
		if (m_is_started == true)
			return true;
		else
			return false;
	}

	void df::Manager::setType(string type) //Ask why we need the parameter
	{
		m_type = type;
	}

	string df::Manager::getType()const
	{
		return m_type;
	}

	int df::Manager::onEvent(Event* p_event)const
	{
		int count = 0;
		std::vector<Object*> all_objects = WM.getAllObjects();
		std::vector<Object*>::iterator li = all_objects.begin();
		while (li != all_objects.end())
		{
			(*li)->eventHandler(p_event);
			count++;
		}
		return count;
	}