#pragma once
enum Color
{
	UNDEFINED_COLOR = -1,
	BLACK = 0,
	RED,
	GREEN,
	YELLOW,
	BLUE,
	MAGENTA,
	CYAN,
	WHITE,
};
const Color COLOR_DEFAULT = WHITE;

