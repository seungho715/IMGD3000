#pragma once
#include "Manager.h"

// Two-letter acronym for easier access to manager.
#define GM df::GameManager::getInstance()

namespace df {
	const int FRAME_TIME_DEFAULT = 33;
	class GameManager : public df::Manager {
	private:
		GameManager();
		GameManager(GameManager const&);
		void operator=(GameManager const&);
		bool game_over;
		int frame_time;
	public:
		//Get the singleton instance of the GameManager
		static GameManager& getInstance();

		//StartUp all GameManager services
		int startUp();

		//Shutdown GameManager services
		void shutDown();

		//Run Game Loop
		int run();

		//Set game over status to indicated value
		//If true (default), will stop game loop
		void setGameOver(bool new_game_over = true);

		//Get game over status
		bool getGameOver() const;

		//Return Frame time.
		//Frame time is target time for game loop, in milliseconds 
		int getFrameTime() const;
	};
}
