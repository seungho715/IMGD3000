#include "InputManager.h"
#include "DisplayManager.h"
#include "EventKeyBoard.h"
#include "EventMouse.h"
#include "EventStep.h"


using namespace df;

InputManager::InputManager()
{
	setType("InputManager");

}
InputManager &InputManager::getInstance()
{
	static InputManager single_im;
	return single_im;
}

int InputManager::startUp()
{
	if (DM.isStarted() == -1)
	{
		return -1;
	}
	//Disable keyrepeat
	//DM.getWindow()->setKeyRepeatEnabled(false);
	//Manager::startUp();
	return 0;
}

void InputManager::shutDown()
{
	sf::RenderWindow* window = DM.getWindow();
	//Enable keyrepeat
	window->setKeyRepeatEnabled(true);
	Manager::shutDown();
}

void InputManager::getInput()
{
	sf::Event event;
	sf::RenderWindow* window = DM.getWindow();
	while (window->pollEvent(event))
	{
		//Key was pressed
		if (event.type == sf::Event::KeyPressed)
		{
			EventKeyBoard key = EventKeyBoard();
			onEvent(&key);
		}
		else if (event.type == sf::Event::KeyReleased)
		{
			EventKeyBoard key = EventKeyBoard();
			onEvent(&key);
		}
		else if (event.type == sf::Event::MouseMoved)
		{
			EventMouse mouse = EventMouse();
			onEvent(&mouse);
		}
		else if (event.type == sf::Event::MouseButtonPressed)
		{
			EventMouse mouse = EventMouse();
			onEvent(&mouse);
		}
	}
	if (sf::Keyboard::Up)
	{
		EventKeyBoard key = EventKeyBoard();
		onEvent(&key);
	}
	else if (sf::Keyboard::Down)
	{
		EventKeyBoard key = EventKeyBoard();
		onEvent(&key);
	}
	if (sf::Mouse::Left)
	{
		EventMouse mouse = EventMouse();
		onEvent(&mouse);
	}
	else if (sf::Mouse::Right)
	{
		EventMouse mouse = EventMouse();
		onEvent(&mouse);
	}
}
