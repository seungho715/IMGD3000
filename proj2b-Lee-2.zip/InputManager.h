#pragma once
#include "Manager.h"
#include <vector>
#include "Object.h"

#define IM df::InputManager::getInstance()

namespace df {

	class InputManager : public df::Manager
	{
	private:
		InputManager();
		InputManager(InputManager const&);
		void operator=(InputManager const&);
	public:
		//Get one and only instance of inputmanager
		static InputManager& getInstance();

		//Get terminal ready to capture input
		//Return 0 ok, else return -1
		int startUp();

		//Revert back to normal terminal mode. 
		void shutDown();

		//Get input from the keyboard and mouse
		//Pass event along to all objects
		void getInput();
	};
}

