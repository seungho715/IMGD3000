#include "EventOut.h"

EventOut::EventOut() {
	setType(OUT_EVENT);
}