#include "Void.h"
#include "WorldManager.h"

Void::Void() {
	setSprite("Void");
	setType("Void");
	setPosition(df::Vector(0, 0));
	setAltitude(4);
	setSolidness(df::SPECTRAL);
}

Void::~Void() {
	WM.markForDelete(this);
}
