#pragma once
#include "Object.h"
#include "EventCollision.h"
namespace df {
	class SkySpikes : public Object
	{
	private:
		void moveToStart();
		void out();
		void hit(const EventCollision* p_c);
	public:
		SkySpikes();
		~SkySpikes();
		int eventHandler(const Event* p_e);
	};
}

