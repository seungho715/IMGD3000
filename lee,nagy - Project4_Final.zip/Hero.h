#include "Object.h"
#include "EventKeyboard.h"
#include "EventCollision.h"

namespace df {
	class Hero : public Object {
	private:
		void kbd(const EventKeyboard* p_keyboard_event);
		void out();
		void jump();
		void step();
		void hit(const EventCollision* p_c);
		bool jumped;
	public:
		Hero();
		~Hero();
		int eventHandler(const Event* p_e);

	};
}