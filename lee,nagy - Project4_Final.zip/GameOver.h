#pragma once
#include "ViewObject.h"
namespace df {
	class GameOver : public ViewObject
	{
	private:
		int time_to_live;
		void step();	
	public:
		GameOver();
		~GameOver();	
		int eventHandler(const Event* p_e);
		int draw();
	};
}

