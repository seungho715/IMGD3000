#include "Hero.h"
#include "WorldManager.h"
#include "EventStep.h"
#include "EventOut.h"
#include "GameOver.h"
#include "Sound.h"
#include "ResourceManager.h"
#include "DisplayManager.h"
using namespace df;

Hero::Hero() {
	setSprite("Hero");
	//gravity
	setVelocity(df::Vector(0, 0.30));
	setType("Hero");
	//puts hero around center of world on start of game
	setPosition(df::Vector(WM.getBoundary().getHorizontal() / 2, 10));
	registerInterest(df::KEYBOARD_EVENT);
	registerInterest(df::STEP_EVENT);
	registerInterest(df::OUT_EVENT);
}
void Hero::out() {
	//if you land at the bottom of the screen, lose velocity
	if (getPosition().getY() <= 0) {
		setPosition(Vector(getPosition().getX(), 0));
		setVelocity(Vector(0, 0));
	}
	//if consumed by void, die
	if (getPosition().getX() <= 0) {
		WM.markForDelete(this);
	}
}
void Hero::step() {
	//of you go above the screen, push hero down and lose velocity, like hitting a ceiling
	if (getPosition().getY() > WM.getBoundary().getVertical()-2) {
		setPosition(df::Vector(getPosition().getX(), WM.getBoundary().getVertical() - 2));
		setVelocity(df::Vector(0, 0));
		jumped = false;
	}
	if (jumped) {
		//if its not at terminal velocity
		if (getVelocity().getY() <= 0.30) {
			setVelocity(df::Vector(getVelocity().getX(), getVelocity().getY() + 0.02));
		}
		//gets rid of x collision velocity after a certain point in the jump
		if (getVelocity().getY() >= -.16) {
			setVelocity(df::Vector(0, getVelocity().getY()));
		}
	}
}
void Hero::jump() {
	//sets velocity for initial jump
	setVelocity(df::Vector(getVelocity().getX(), -0.50));
	Sound* p_sound = ResourceManager::getInstance().getSound("jump");
	p_sound->play();
}
void Hero::kbd(const df::EventKeyboard* p_event_keyboard) {
	//jump events
	if (p_event_keyboard->getKey() == df::Keyboard::SPACE) {
		if (p_event_keyboard->getKeyboardAction() == df::KEY_PRESSED) {
			jump();
			jumped = true;
		}
	}
}
int Hero::eventHandler(const df::Event* p_e) {
	//Based off of how eventHandler in saucer shoot is set up
	if (p_e->getType() == df::KEYBOARD_EVENT) {
		//if space bar, jump
		const df::EventKeyboard* p_kbd_event = dynamic_cast <const df::EventKeyboard*> (p_e);
		kbd(p_kbd_event);
		return 1;
	}
	if (p_e->getType() == df::STEP_EVENT) {
		//step events on each iteration
		step();
		return 1;
	}
	if (p_e->getType() == df::OUT_EVENT) {
		//if player is out of bounds
		out();
		return 1;
	}
	//if colliding with something
	if (p_e->getType() == COLLISION_EVENT) {
		const EventCollision* p_collision_event = dynamic_cast <EventCollision const*> (p_e);
		hit(p_collision_event);
		return 1;
	}
	
	return 0;
}

Hero::~Hero()
{
	// Create GameOver object.
	new GameOver;
	//Sound of Death 
	Sound* p_sound = ResourceManager::getInstance().getSound("die");
	p_sound->play();
	// Shake screen (severity 20 pixels x&y, duration 10 frames).
	DM.shake(20, 20, 10); //Added Effect after Hero dying. 
}

void Hero::hit(const EventCollision* p_c) {
	//checking collisions if colliding with a bar, if on a bar, stop velocity
	if ((p_c->getObject1()->getType() == "bars") || (p_c->getObject2()->getType() == "bars"))
	{
		if (p_c->getObject1()->getType() == "bars")
		{
			if ((p_c->getObject1()->getPosition().getX() + p_c->getObject1()->getBox().getHorizontal()) == p_c->getObject2()->getBox().getCorner().getX())
			{
				p_c->getObject2()->setVelocity(Vector(0, 0));
			}
		}
		else
		{
			if ((p_c->getObject2()->getPosition().getX() + p_c->getObject2()->getBox().getHorizontal()) == p_c->getObject1()->getBox().getCorner().getX())
			{
				p_c->getObject1()->setVelocity(Vector(0, 0));
			}
		}
	}
	
}