#include "Bars.h"
#include "EventOn.h"

#include "LogManager.h"
#include "WorldManager.h"
#include "ResourceManager.h"
#include "EventOut.h"
#include "EventCollision.h"
#include "EventView.h"
#include "Points.h"
#include <stdlib.h>
using namespace df;

Bars::Bars()
{
	// set up "Bars" sprite
	setSprite("Bars");

	// Set up "Bars" type
	setType("Bars");

	// Set speed in horizontal direction
	setVelocity(Vector(-0.35, 0));

	//Starting location
	moveToStart();

	//Registering Event
	registerInterest(ON_EVENT);
}

int Bars::eventHandler(const Event* p_e)
{
	//for going out of border
	if (p_e->getType() == OUT_EVENT)
	{
		out();
		return 1;
	}
	//for collision with objects
	if (p_e->getType() == COLLISION_EVENT) {
		const EventCollision* p_collision_event = dynamic_cast <EventCollision const*> (p_e);
		hit(p_collision_event);
		return 1;
	}

	return 0;
}

//Detect if the bars are out of bound, and if it is then delete the bars. 
void Bars::out()
{
	//Getting the position to mark for delete 
	if (getPosition().getX() >= 0)
	{
		return;
	}
	//Delete out-of-bound bars to reduce glitches 
	else {
		WM.markForDelete(this);
	}
	//else after deleting
	moveToStart();

	// Spawn new Bars to make the game get harder.
	new Bars;
}

//method to know when to start and how to start. 
void Bars::moveToStart()
{
	Vector temp_pos;

	float world_horiz = WM.getBoundary().getHorizontal();
	float world_vert = WM.getBoundary().getVertical();

	// x is off right side of window
	temp_pos.setX(world_horiz + rand() % (int)world_horiz + 3.0f);

	// y is in vertical range
	//Spawn randomly, but between spikes
	temp_pos.setY(rand() % (int)(world_vert - 11) + 4.0f);

	// If collision, move right slightly until empty space.
	df::ObjectList collision_list = WM.getCollisions(this, temp_pos);
	while (!collision_list.isEmpty()) {
		temp_pos.setX(temp_pos.getX() + 1);
		collision_list = WM.getCollisions(this, temp_pos);
	}
	//Move the Object to position
	WM.moveObject(this, temp_pos);
}

// Called when Bars collides.
void Bars::hit(const df::EventCollision* p_c) {
	// If Bars on Bars, ignore.
	if ((p_c->getObject1()->getType() == "Bars") && (p_c->getObject2()->getType() == "Bars"))
		return;

	//If Bars on Spikes, ignore
	if ((p_c->getObject1()->getType() == "Bars") && (p_c->getObject2()->getType() == "Spikes"))
		return;

	// If Hero, depending on the type of collision, perform different actions.
	if (((p_c->getObject1()->getType()) == "Hero") || ((p_c->getObject2()->getType()) == "Hero"))
	{
		//Can safely land on top of the bar. 
		if (p_c->getObject1()->getType() == "Hero")
		{
			if (p_c->getObject1()->getBox().getCorner().getX() + p_c->getObject1()->getBox().getHorizontal() >= p_c->getObject2()->getBox().getCorner().getX() &&
				p_c->getObject1()->getBox().getCorner().getX() + p_c->getObject1()->getBox().getHorizontal() <= p_c->getObject2()->getBox().getCorner().getX() +
				p_c->getObject2()->getBox().getHorizontal())
			{
				p_c->getObject1()->setVelocity(Vector(p_c->getObject2()->getVelocity().getX(), p_c->getObject1()->getVelocity().getY()));
			}
			
		}
		if (p_c->getObject2()->getType() == "Hero")
		{
			if (p_c->getObject2()->getBox().getCorner().getX() + p_c->getObject2()->getBox().getHorizontal() > p_c->getObject1()->getBox().getCorner().getX() &&
				p_c->getObject2()->getBox().getCorner().getX() + p_c->getObject2()->getBox().getHorizontal() < p_c->getObject1()->getBox().getCorner().getX() +
				p_c->getObject1()->getBox().getHorizontal())
			{
				p_c->getObject2()->setVelocity(Vector(p_c->getObject1()->getVelocity().getX(), p_c->getObject2()->getVelocity().getY()));
			}
			
		}
	}

}

Bars::~Bars() {

}