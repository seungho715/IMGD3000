#pragma once
#include "Object.h"
#include "EventCollision.h"
namespace df {
	class Spikes : public Object
	{
	private:
		void moveToStart();
		void out();
		void hit(const EventCollision* p_c);
	public:
		Spikes();
		~Spikes();
		int eventHandler(const Event* p_e);
	};
}

