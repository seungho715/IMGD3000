#include "Object.h"
class Void : public df::Object {
public:
	Void();
	~Void();
};
