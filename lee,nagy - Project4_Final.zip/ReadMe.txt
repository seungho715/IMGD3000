Seungho Lee - slee7@wpi.edu
Matthew Nagy = managy@wpi.edu

For the platform, we used the newest version of Visual Studio 2019. 
All the source codes are in the directory: C:\Users\Owner\Documents\Visual Studio 2019\Project4\Project4. There are some dll files, Sprites, 
and music inside the directory. 

We coded similarly to Saucer-Shoot, which there are different classes for different objects and scenarios. 
For Objects, we have stars(for the background), Bars, Spikes, and SkySpikes(for obstacles), and Hero(for main character). 
For scenaiors, we have gamestart, gameover, and game. GameStart starts the game, GameOver ends the game and restarts(which currently doesnt
clear the gameworld and restarting repeatedly floods the gameworld with more obstacles). Game loads the sprite
populate the world to the screen. 

However, the game is not finalized yet. For Hero, we successfully implemented the jumping mechanism, but there are some minor bugs with 
collision with bars. 

To compile the code, you will have to include all the dragonfly libraries, dll files, df-font, and dragongly include files in configuration.
Then, it will successfully compile. 

