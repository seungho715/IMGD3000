#include "GameManager.h"
#include "LogManager.h"
#include "ResourceManager.h"
#include "Color.h"
#include "Pause.h"
#include "GameStart.h"
#include "Star.h"
#include "Hero.h"

using namespace df;

void loadResources(void);
void populateWorld(void);

int main(int argc, char* argv[])
{
	//StartUp GameManager
	if (GM.startUp())
	{
		LM.writeLog("Error starting game manager!");
		GM.shutDown();
		return 0;
	}
	LM.setFlush(true);

	// load game resources
	loadResources();

	// populate game world with objects
	populateWorld();

	// Start Running the game
	GM.run();

	// Start over the game
	GM.setGameOver();

	// Shut everything down.
	GM.shutDown();
}

void loadResources(void)
{
	//Loading Sprites
	RM.loadSprite("sprites/gamestart-spr.txt", "GameStart");

	RM.loadSprite("sprites/bars-spr.txt", "Bars");

	RM.loadSprite("sprites/gameover-spr.txt", "GameOver");

	RM.loadSprite("sprites/spikes-spr.txt", "Spikes");

	RM.loadSprite("sprites/heroproto-spr.txt", "Hero");

	RM.loadSprite("sprites/skyspike-spr.txt", "SkySpikes");

	RM.loadSprite("sprites/void-spr.txt", "Void");

	// Load Soundeffect
	RM.loadSound("sounds/Jump.wav", "jump");

	RM.loadSound("sounds/Death_Explosion.wav", "die");

	//Load Music
	RM.loadMusic("sounds/Music_Background.wav", "start music");
}

void populateWorld(void)
{
	// Generate Stars for the background
	for (int i = 0; i < 16; i++)
	{
		new Star;
	}

	// Spawn GameStart object.
	new GameStart();
	// Enable player to pause game.
	new Pause(Keyboard::F10);
}
