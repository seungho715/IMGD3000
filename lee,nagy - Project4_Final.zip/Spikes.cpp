#include "Spikes.h"

#include "LogManager.h"
#include "WorldManager.h"
#include "ResourceManager.h"
#include "EventOut.h"
#include "EventCollision.h"
#include "EventView.h"
#include <stdlib.h>
using namespace df;

Spikes::Spikes()
{
	// set up "Spikes" sprite
	setSprite("Spikes");

	// Set up "Spikes" type
	setType("Spikes");

	// Set speed in horizontal direction
	setVelocity(Vector(-0.25, 0));

	//Starting location
	moveToStart();
}

int Spikes::eventHandler(const Event* p_e)
{
	//for going out of border
	if (p_e->getType() == OUT_EVENT)
	{
		out();
		return 1;
	}
	//for collision
	if (p_e->getType() == COLLISION_EVENT) {
		const EventCollision* p_collision_event = dynamic_cast <EventCollision const*> (p_e);
		hit(p_collision_event);
		return 1;
	}

	return 0;
}

void Spikes::out()
{
	if (getPosition().getX() >= 0)
	{
		return;
	}
	else
	{
		WM.markForDelete(this);
	}
	//else
	moveToStart();

	// Spawn new Spikes to make the game get harder.
	new Spikes;
}

//method to know when to start and how to start. 
void Spikes::moveToStart()
{
	Vector temp_pos;

	float world_horiz = WM.getBoundary().getHorizontal();
	float world_vert = WM.getBoundary().getVertical();

	// x is off right side of window
	temp_pos.setX(world_horiz + rand() % (int)world_horiz + 3.0f);

	// y is in vertical range
	temp_pos.setY(world_vert-2);

	// If collision, move right slightly until empty space.
	df::ObjectList collision_list = WM.getCollisions(this, temp_pos);
	while (!collision_list.isEmpty()) {
		temp_pos.setX(temp_pos.getX() + 1);
		collision_list = WM.getCollisions(this, temp_pos);
	}

	WM.moveObject(this, temp_pos);
}

// Called when Spikes collides.
void Spikes::hit(const df::EventCollision* p_c) {

	// If Spikes on Spikes, ignore.
	if ((p_c->getObject1()->getType() == "Spikes") && (p_c->getObject2()->getType() == "Spikes"))
		return;
	// If Spikes on Bars, ignore
	if ((p_c->getObject1()->getType() == "Spikes") && (p_c->getObject2()->getType() == "Bars"))
		return;

	// If Hero, mark both objects for destruction.
	if (((p_c->getObject1()->getType()) == "Hero") || ((p_c->getObject2()->getType()) == "Hero"))
	{
		if (p_c->getObject1()->getType() == "Hero")
		{
			WM.markForDelete(p_c->getObject1());
		}
		else if (p_c->getObject2()->getType() == "Hero")
		{
			WM.markForDelete(p_c->getObject2());
		}
	}

}

Spikes::~Spikes() {

}