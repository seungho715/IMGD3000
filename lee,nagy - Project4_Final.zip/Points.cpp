#include "Points.h"
#include "EventOn.h"
#include "Bars.h"
#include "Event.h"
#include "EventStep.h"
#include "LogManager.h"
#include "EventOut.h"
using namespace df;

//Constructor for Points
Points::Points()
{
	// Sets the location to top right
	setLocation(BOTTOM_RIGHT);

	// Sets the view of the string
	setViewString(POINTS_STRING);

	// Sets the Color to Yellow
	setColor(RED);

	// Need to update score each second, so count "step" events.
	registerInterest(STEP_EVENT);

	// Need to update score each jump, so count "keyboard" events
	registerInterest(KEYBOARD_EVENT);
}

//Method that handles different events for different ways(KBD, Mouse, and more)
int Points::eventHandler(const Event* p_e) {

	// Parent handles event if score update.
	if (ViewObject::eventHandler(p_e))
	{
		return 1;
	}

	// If step, increment score every second (50 steps).
	if (p_e->getType() == STEP_EVENT)
	{
		if (dynamic_cast <const EventStep*> (p_e)->getStepCount() % 50 == 0)
		{
			setValue(getValue() + 1);
		}
		return 1;
	}
	//If Keyboard, increment score for every jump 
	if (p_e->getType() == KEYBOARD_EVENT)
	{
		const EventKeyboard* k_e = dynamic_cast <const EventKeyboard*> (p_e);
		if (k_e->getKey() == Keyboard::SPACE)
		{
			if (k_e->getKeyboardAction() == KEY_PRESSED)
			{
				setValue(getValue() + 10);
			}
		}
		//Easter Egg for the game. Gains 1000 points automatically
		if (k_e->getKey() == Keyboard::S)
		{
			if (k_e->getKeyboardAction() == KEY_PRESSED)
			{
				setValue(getValue() + 1000);
			}
		}
		return 1;
	}

	// If get here, have ignored this event.
	return 0;
}
