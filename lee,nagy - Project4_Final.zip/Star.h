#pragma once

#include "Object.h"

#define STAR_CHAR '.'
namespace df {
	class Star : public Object {
		//private variable and method only used in Explosion class
	private:
		void out();

		//public methods that can be used in various classes
	public:
		Star();
		int draw(void);
		int eventHandler(const Event* p_e);
	};
}

