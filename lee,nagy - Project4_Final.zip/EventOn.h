#pragma once
#include "EventCollision.h"
const std::string ON_EVENT = "on";

class EventOn : public df::EventCollision {

	//public method. 
public:
	EventOn();
};


