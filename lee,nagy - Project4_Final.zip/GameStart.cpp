#include "GameStart.h"
#include "EventKeyboard.h"
#include "GameManager.h"
#include "LogManager.h"
#include "ResourceManager.h"
#include "WorldManager.h"
#include "Music.h"

#include "Bars.h"
#include "Spikes.h"
#include "SkySpikes.h"
#include "Hero.h"
#include "Void.h"
#include "Points.h"

using namespace df;

GameStart::GameStart()
{
	//Set type to GameStart
	setType("GameStart");

	//Link to "message" Sprite
	setSprite("GameStart");

	//Set position on the screen
	setPosition(Vector(39, 10));

	//Register for keyboard event
	registerInterest(KEYBOARD_EVENT);

	//Play start music
	p_music = RM.getMusic("start music");
	playMusic();
}

int GameStart::eventHandler(const Event* p_e)
{
	//checking input for what to do with game
	if (p_e->getType() == KEYBOARD_EVENT)
	{
		EventKeyboard* p_keyboard_event = (EventKeyboard*)p_e;
		switch (p_keyboard_event->getKey())
		{
		case Keyboard::P:
			start();
			break;
		case Keyboard::Q:
			GM.setGameOver();
			break;
		}
		return 1;
	}
	return 0;
}

void GameStart::start()
{
	//Create Hero/Main Character
	new Hero;

	new Void;
	//Spawn obstacles to jump
	for (int i = 0; i < 16; i++)
	{	
		if (i % 2 == 0) {
			new Bars;
		}
		new Spikes;
		new SkySpikes;
	}
	// Points display.
	new Points;		               

	//When game starts, become inactive
	setActive(false);

}

int GameStart::draw()
{
	return Object::draw();
}

void GameStart::playMusic()
{
	p_music->play();
}

