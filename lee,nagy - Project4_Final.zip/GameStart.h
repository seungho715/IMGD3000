#pragma once
#include "ViewObject.h"
#include "Music.h"
#include "Sound.h"

namespace df {
	class GameStart : public ViewObject
	{
	private:
		Music* p_music;
		void start();
	public:
		GameStart();
		int eventHandler(const Event* p_e);
		int draw();
		void playMusic();
	};
}


