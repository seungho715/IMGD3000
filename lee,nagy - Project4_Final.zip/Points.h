#pragma once
#include "ViewObject.h"
#include "Event.h"

#define POINTS_STRING "Points"
namespace df {
	class Points : public df::ViewObject {
		//public methods that can be used in various classes
	public:
		Points();
		int eventHandler(const Event* p_e);
		bool extraPoints(bool onBar);
	};
}
