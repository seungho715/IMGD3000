#include "EventOn.h"

EventOn::EventOn() {
	setType(ON_EVENT);
};
