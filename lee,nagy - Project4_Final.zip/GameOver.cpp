#include "GameOver.h"
#include "EventStep.h"
#include "LogManager.h"
#include "ResourceManager.h"
#include "WorldManager.h"
#include "GameStart.h"
using namespace df;

GameOver::GameOver() {

	setType("GameOver");

	// Link to "message" sprite.
	if (setSprite("GameOver") == 0) {
		time_to_live = getAnimation().getSprite()->getFrameCount() * getAnimation().getSprite()->getSlowdown();
	}
	else {
		time_to_live = 0;
	}

	// Put in center of window.
	setLocation(CENTER_CENTER);

	// Register for step event.
	registerInterest(STEP_EVENT);
}

// When done, game over so reset things for GameStart.
GameOver::~GameOver() {

	// Remove Objects and ViewObjects, re-activate GameStart.
	ObjectList object_list = WM.getAllObjects(true);
	ObjectListIterator i(&object_list);
	for (i.first(); !i.isDone(); i.next())
	{
		Object* p_o = i.currentObject();
		if (p_o->getType() == "Bars" || p_o->getType() == "ViewObject" || p_o->getType() == "Spikes" || p_o->getType() == "SkySpikes" || p_o->getType() == "Void") //If anything left, delete the leftover
		{
			WM.markForDelete(p_o);
		}
		if (p_o->getType() == "GameStart") {
			p_o->setActive(true);
			dynamic_cast <GameStart*> (p_o)->playMusic(); // Resume start music.
		}


	}
}

// Handle event.
// Return 0 if ignored, else 1.
int GameOver::eventHandler(const Event* p_e) {
	//Step Event for gameover 
	if (p_e->getType() == STEP_EVENT) {
		step();
		return 1;
	}

	// If get here, have ignored this event.
	return 0;
}

// Count down to end of message.
void GameOver::step() {
	time_to_live--;
	if (time_to_live <= 0)
		WM.markForDelete(this);
}

// Override default draw so as not to display "value".
int GameOver::draw() {
	return Object::draw();
}