#include "DisplayManager.h"
#include <iostream>
#include <SFML/Graphics.hpp>

using namespace df;

DisplayManager::DisplayManager()
{
	m_p_window = NULL;
	m_window_horizontal_pixels = WINDOW_HORIZONTAL_PIXELS_DEFAULT;
		m_window_vertical_pixels = WINDOW_VERTICAL_PIXELS_DEFAULT;
		m_window_horizontal_chars = WINDOW_HORIZONTAL_CHARS_DEFAULT;
		m_window_vertical_chars = WINDOW_VERTICAL_CHARS_DEFAULT;
		setType("DisplayManager");
}
int DisplayManager::startUp()
{
	if (m_p_window != NULL)
	{
		return 0;
	}

	m_p_window = 
		new sf::RenderWindow(sf::VideoMode(WINDOW_HORIZONTAL_PIXELS_DEFAULT, WINDOW_VERTICAL_PIXELS_DEFAULT), "Title - Dragonfly", sf::Style::Titlebar);
	if (!m_p_window)
	{
		std::cout << "Error! Unable to allocate RenderWindow." << std::endl;
		return -1;
	}

	//Turn Off mouse cursor for window
	m_p_window->setMouseCursorVisible(false);

	//Synchronize refresh rate with monitor
	m_p_window->setVerticalSyncEnabled(true);
	sf::Font font;
	if (font.loadFromFile("df-font.ttf") == false)
	{
		std::cout << "Error! Unable to load font 'df-font.ttf'." << std::endl;
		return -1;
	}
	else
	{
		df::Manager::startUp();
		return 0;
	}
	return -1;
}

void DisplayManager::shutDown()
{
	Manager::shutDown();
}

DisplayManager& DisplayManager::getInstance()
{
	static DisplayManager single_dm;
	return single_dm;
}

int DisplayManager::drawCh(Vector world_pos, char ch, Color color)const
{
	//Make sure window is allocated
	if (m_p_window == NULL)
	{
		return -1;
	}

	//Convert spaces (x,y) to pixels (x,y)
	Vector pixel_pos = spacesToPixels(world_pos);

	//Draw background rectangle	since text is "see through" in SFML
	static sf::RectangleShape rectangle;
	rectangle.setSize(sf::Vector2f(charWidth(), charHeight()));
	rectangle.setFillColor(WINDOW_BACKGROUND_COLOR_DEFAULT);
	rectangle.setPosition(pixel_pos.getX() - charWidth()/10, pixel_pos.getY() + charHeight()/5);
	m_p_window->draw(rectangle);

	//Create character text to draw
	static sf::Text text("", m_font);
	text.setString(ch);
	text.setStyle(sf::Text::Bold);

	//Scale to right size
	if (charWidth() < charHeight())
	{
		text.setCharacterSize(charWidth() * 2);
	}
	else
		text.setCharacterSize(charHeight() * 2);

	//set SFML color based on Dragonfly color.
	switch (color)
	{
	case YELLOW:
		text.setFillColor(sf::Color::Yellow);
		break;
	case RED:
		text.setFillColor(sf::Color::Red);
		break;
	case GREEN:
		text.setFillColor(sf::Color::Green);
		break;
	case BLUE:
		text.setFillColor(sf::Color::Blue);
		break;
	case MAGENTA:
		text.setFillColor(sf::Color::Magenta);
		break;
	case CYAN:
		text.setFillColor(sf::Color::Cyan);
		break;
	case WHITE:
		text.setFillColor(sf::Color::White);
		break;
	}

	//Set position in window
	text.setPosition(pixel_pos.getX(), pixel_pos.getY());

	//Draw Character
	m_p_window->draw(text);

	return 0;
}

//Compute Character height, based on window size and font
float df::charHeight()
{
	return (DM.getVerticalPixels() / DM.getVertical());
}

//compute character width, based on window size and font
float df::charWidth()
{
	return(DM.getHorizontalPixels() / DM.getHorizontal());
}

//convert ASCII spaces(x,y) to window pixels (x,y)
Vector df::spacesToPixels(Vector spaces)	
{
	spaces.setX(spaces.getX() * charWidth());
	spaces.setY(spaces.getY() * charHeight());
	return spaces;
}

//convert window pixels (x,y) to ASCII spaces (x,y)
Vector df::pixelsToSpaces(Vector pixels)
{
	pixels.setX(pixels.getX() / charWidth());
	pixels.setY(pixels.getY() / charHeight());
	return pixels;
}

int DisplayManager::getHorizontal()const
{
	return m_window_horizontal_chars;
}

int DisplayManager::getHorizontalPixels()const
{
	return m_window_horizontal_pixels;
}

int DisplayManager::getVertical()const
{
	return m_window_vertical_chars;
}

int DisplayManager::getVerticalPixels()const
{
	return m_window_vertical_pixels;
}

sf::RenderWindow* DisplayManager::getWindow()const
{
	return m_p_window;
}

int DisplayManager::swapBuffers()
{
	//Make sure window is allocated
	if (m_p_window == NULL)
	{
		return -1;
	}

	//Display Current Window
	m_p_window->display();

	//Clear other window to get ready for next step
	m_p_window->clear();

	return 0;
}

int DisplayManager::drawString(Vector pos, std::string str, Justification just, Color color)const
{
	//Get Starting position
	Vector starting_pos = pos;
	switch (just)
	{
	case CENTER_JUSTIFIED:
		starting_pos.setX(pos.getX() - str.size() / 2);
		break;
	case RIGHT_JUSTIFIED:
		starting_pos.setX(pos.getX() - str.size());
		break;
	case LEFT_JUSTIFIED:
	default:
		break;
	}

	//Draw string character by character
	for (int i = 0; i < str.size(); i++)
	{
		Vector temp_pos(starting_pos.getX() + i, starting_pos.getY());
		drawCh(temp_pos, str[i], color);
	}
	return 0; 
}
