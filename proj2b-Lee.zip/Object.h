#pragma once
#include <string>
#include "Vector.h"
#include "Event.h"
namespace df {
	enum Solidness {
		HARD,
		SOFT,
		SPECTRAL,
	};
	class Object
	{
	private:
		int m_id;
		std::string m_type;
		Vector m_position;
		int m_altitude;
		Vector m_direction;
		float m_speed;
		Solidness m_solidness;
		bool m_no_soft;

	public:
		//Construct Object. Set default parameters and
		//add to game world(WorldManager)
		Object();

		//Destroy Object. 
		//Remove from game world(WorldManager)
		virtual ~Object();

		//Set Object ID
		void setId(int new_id);

		//Get Object ID
		int getId() const;

		//Set type identifier of object
		void setType(std::string new_type);

		//Get type identifier of object
		std::string getType() const;

		//Set position of Object
		void setPosition(Vector new_pos);

		//Get positin of Object
		Vector getPosition() const;

		//EventHandler
		virtual int eventHandler(Event* p_e);

		//draw
		virtual int draw();

		//Set altitude of Object with checks for range[0,max]
		int setAltitude(int new_altitude);

		//Return altitude of Object
		int getAltitude()const;

		//Set speed of Object
		void setSpeed(float speed);

		//Get speed of Object
		float getSpeed()const;

		//Set direction of Object
		void setDirection(Vector new_direction);

		//Get direction of Object
		Vector getDirection()const;

		//Set velocity of Object based on direction and speed
		void setVelocity(Vector new_velocity);

		//Get velocity of Object
		Vector getVelocity()const;

		//predict Object position based on speed and direction
		Vector predictPosition();
		
		//True if HARD or SOFT, else false
		bool isSolid()const;

		//Set object solidness, with checks	for consistency 
		//Return 0 if ok, else -1
		int setSolidness(Solidness new_solid);

		//Return object solidness
		Solidness getSolidness()const;

		//Set "no soft" setting (true - cannot move onto SOFT Objects)
		void setNoSoft(bool new_no_soft = true);

		//Get "no soft" setting(true - cannot move onto SOFT Objects)
		bool getNoSoft()const;
	};

}