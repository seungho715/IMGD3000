#include "Clock.h"
#include <Windows.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

SYSTEMTIME before_st, after_st;

Clock::Clock()
{
	m_previous_time = 0;
};

long int Clock::delta()
{
	GetSystemTime(&before_st);
	GetSystemTime(&after_st);
	long int before_msec = (before_st.wMinute * 60 * 1000000) + (before_st.wSecond * 1000000) + (before_st.wMilliseconds * 1000);
	long int after_msec = (before_st.wMinute * 60 * 1000000) + (before_st.wSecond * 1000000) + (before_st.wMilliseconds * 1000);
	clock_t elapsed = after_msec - before_msec;
	m_previous_time = elapsed;
	return elapsed;
}

long int Clock::split()const
{
	GetSystemTime(&before_st);
	GetSystemTime(&after_st);
	long int before_msec = (before_st.wMinute * 60 * 1000000) + (before_st.wSecond * 1000000) + (before_st.wMilliseconds * 1000);
	long int after_msec = (before_st.wMinute * 60 * 1000000) + (before_st.wSecond * 1000000) + (before_st.wMilliseconds * 1000);
	clock_t elapsed = after_msec - before_msec;
	return elapsed;
}

long int Clock::returnClock()
{
	return m_previous_time;
}

