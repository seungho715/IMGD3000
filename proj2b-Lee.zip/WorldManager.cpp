#include "WorldManager.h"
#include "Object.h"
#include <vector>
#include <iostream>
#include "Manager.h"
#include "Event.h"
#include "EventCollision.h"
#include "EventOut.h"

using namespace df;

//Constructor for the WorldManager class 
//Initializes all varialbes and types
WorldManager::WorldManager()
{
	m_updates.clear();
	m_deletions.clear();
	setType("WorldManager");
}

//Making an Instance of WorldManager 
//Singleton Method
WorldManager &WorldManager::getInstance()
{
	static WorldManager single_wm;
	return single_wm;
}

//StartUp WorldManager, but not used for Project 2a
int WorldManager::startUp()
{
	m_updates.clear();
	m_deletions.clear();
	return(Manager::startUp());
}

//ShutDown WorldManager, activates the destructor for Objects
void WorldManager::shutDown()
{
	//Delete All Game Objects
	std::vector<Object*> ol = m_updates;
	std::vector<Object*>::iterator li = ol.begin();
	for (li = ol.begin(); li !=ol.end(); li++)
	{
		delete *li;
	}
	Manager::shutDown();
}

//Inserts Object to the Game while updating
//Uses m_updates for inserting
int WorldManager::insertObject(Object* p_o)
{
	m_updates.push_back(p_o);
	return 1;
}

//Deletes Object to the Game while deleting
//Uses m_deletion for deleting
int WorldManager::removeObject(Object* p_o)
{
	std::vector<Object*> copy = m_updates;
	std::vector<Object*>::iterator li = m_updates.begin();
	for (li = m_updates.begin(); li != m_updates.end(); li++)
	{
		if (p_o == *li)
		{
			m_updates.erase(li);
			return 1;
		}
	}
	return -1;
}

std::vector<Object*> WorldManager::getAllObjects()const
{
	//Returns the updates ObjectList
	return m_updates;
}

std::vector<Object*> WorldManager::objectsofType(std::string type)const
{
	std::vector<Object*> list;
	std::vector<Object*> copy = m_updates;
	std::vector<Object*>::iterator li = copy.begin();
	for (li = copy.begin(); li != copy.end(); li++)
		if ((*li)->getType() == type)
			list.push_back(*li);
	return list;
}

int WorldManager::markForDelete(Object* p_o)
{
	//Object might already have been marked, so only add once.
	std::vector<Object*> ol = m_deletions;
	std::vector<Object*>::iterator li = ol.begin();
	while (li != ol.end())
	{
		if ((*li) == p_o) //will this be a pointer?
		{
			return 0;
		}
		li++;
	}
	//Object not in list, so add. 
	m_deletions.push_back(p_o);
	return -1;
}

void WorldManager::update()
{
	//Delete all marked objects.
	std::vector<Object*> ol = m_deletions;
	std::vector<Object*>::iterator li = ol.begin();
	while (li != ol.end())
	{
		delete *li;
		li++;
	}
	m_deletions.clear();

	//update all object
	std::vector<Object*> ol2 = m_updates;
	std::vector<Object*>::iterator li2 = ol2.begin();
	while (li2 != ol2.end())
	{
		//Add velocity to position
		Vector new_pos = (*li2)->predictPosition();

		//If Object should change position, then move.
		if (new_pos.equals( (*li2)->getPosition()))
		{
			moveObject((*li2),new_pos);
		}
		li2++;
	}
}

void WorldManager::draw()
{
	for (int alt = 0; alt <= MAX_ALTITUDE; alt++)
	{
		std::vector<Object*>::iterator li = m_updates.begin();
		while (li != m_updates.end())
		{
			if ((*li)->getAltitude() == alt)
			{
				Object* p_temp_o = (*li);
				p_temp_o->draw();
				li++;
			}

		}
	}
}

std::vector<Object*> WorldManager::getCollisions(Object* p_o, Vector where)
{
	//Make empty list
	std::vector<Object*> collision_list;
	
	//Iterate through all Objects
	std::vector<Object*>::iterator li = m_updates.begin();

	while (li != m_updates.end())
	{
		Object* p_temp_o = (*li);
		if (p_temp_o != p_o)
		{
			//Same location and both solid?
			if ((df::positionsIntersect(p_temp_o->getPosition(), where) && p_temp_o ->isSolid()))
			{
				collision_list.push_back(p_temp_o);
			}
		}
		li++;
	}
	return collision_list;
}

int WorldManager::moveObject(Object* p_o, Vector where)
{
	if (p_o->isSolid())
	{
		//Get collision
		std::vector<Object*> list = getCollisions(p_o, where);
		if (!list.empty())
		{
			bool do_move = true; //Assume can move

			//Iterate over list
			std::vector<Object*>::iterator li = list.begin();
			while (li != list.end())
			{
				Object* p_temp_o = (*li);

				//Create Collision event 
				EventCollision c(p_o, p_temp_o, where);

				//Send to both Objects
				p_o->eventHandler(&(Event)c);
				p_temp_o->eventHandler(&(Event)c);

				//If both HARD, then cannot move
				if (p_o->getSolidness() == HARD && p_temp_o->getSolidness() == HARD)
				{
					do_move = false;
				}
				//If object does not want to move onto soft objects, don't move
				if (p_o->getNoSoft() && p_temp_o->getNoSoft() == SOFT)
					do_move = false;
				li++;
			}
			if (do_move == false)
			{
				return -1;
			}
		}
	}
	//If here, no collision between two HARD objects so allow move. 
	p_o->setPosition(where);
	//Generate out of bounds event and send to Object
	EventOut ov;
	p_o->eventHandler(&(Event)ov);
	return 0;
}

bool df::positionsIntersect(Vector p1, Vector p2)
{
	if ((abs(p1.getX() - p2.getX() < 1) && abs(p1.getY() - p2.getY() < 1)))
		return true;
	else
		return false;
}

std::vector<Object*> WorldManager::returnUpdates()
{
	return m_updates;
}

std::vector<Object*> WorldManager::returnDeletes()
{
	return m_deletions;
}