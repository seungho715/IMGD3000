#include "EventKeyBoard.h"

EventKeyBoard::EventKeyBoard()
{
	m_key_val = Keyboard::UNDEFINED_KEY;
	m_keyboard_action = UNDEFINED_KEYBOARD_ACTION;
	setType(KEYBOARD_EVENT);
}
void EventKeyBoard::setKey(Keyboard::Key new_key)
{
	m_key_val = new_key;
}

Keyboard::Key EventKeyBoard::getKey()const
{
	return m_key_val;
}

void EventKeyBoard::setKeyboardAction(EventKeyboardAction new_action)
{
	m_keyboard_action = new_action;
}

EventKeyboardAction EventKeyBoard::getKeyboardAction()const
{
	return m_keyboard_action;
}
