#include "LogManager.h"
#include "Clock.h"
#include "Vector.h"
#include "Event.h"
#include "EventStep.h"
#include "GameManager.h"
#include "WorldManager.h"
#include "Object.h"
#include "Manager.h"
#include <iostream>
#include <vector>
#include "InputManager.h"
#include "DisplayManager.h"
#include "Color.h"
#include "EventCollision.h"
#include "EventKeyBoard.h"
#include "EventMouse.h"
#include "EventOut.h"
#include <Windows.h>

using namespace df;

int main(int argc, char* argv[])
{
	//StartUp LogManager
	if (LM.startUp())
	{
		printf("Error starting LogManager! \n");
		return 1;
	}

	//Successfully started, so write some stuff
	LM.writeLog("This is a test");
	LM.writeLog("This is a test %d.", 2);
	LM.writeLog("This is %s %0.1f", "test", 2.5);

	//Shutdown LogManager
	LM.shutDown();

	//Check if Delta is working fine
	Clock* new_clockD = new Clock();
	if (new_clockD->delta() == new_clockD->returnClock())
	{
		LM.writeLog("Delta Functions is working fine");
	}

	//Check if Split is working fine
	Clock* new_clockS = new Clock();
	if (new_clockS->split() > new_clockS->returnClock())
	{
		LM.writeLog("Split Functions is working fine");
	}

	//Check if getType, setType, and Constructor
	EventStep jimbo = EventStep(3);
	if (jimbo.getType() == "STEP_EVENT")
	{
		LM.writeLog("Type is STEP_EVENT!");
	}
	else
	{
		LM.writeLog("Oof...Wrong type");
	}

	//Check getStepCount and setStepCount
	EventStep mumbo = EventStep();
	mumbo.setStepCount(3);
	if (jimbo.getStepCount() == mumbo.getStepCount())
	{
		LM.writeLog("Step Count is working!");
	}
	else
	{
		LM.writeLog("You're step functions aint working BRUH!!!");
	}

	int chris = GM.getFrameTime();
	if (chris == 33)
	{
		LM.writeLog("Frame is 33!");
	}

	//Test for x and y
	Vector v;
	v.setXY(100, 100);
	Vector v2;
	//Test Magnitude
	if (v2.getMagnitude() < v.getMagnitude())
	{
		LM.writeLog("Magnitude Method is Successful!");
	}
	else
		LM.writeLog("Magnitude went right");

		//Test Scale and getter
	v.scale(2);
	if (v.getX() == v.getX() / 2)
		LM.writeLog("Scale and getter works fine");
	else
		LM.writeLog("Scale and getter went wrong!");
	
	//StartUp the WorldManager
	if (WM.startUp())
	{
		printf("Error starting WorldManager! \n");
		return 1;
	}
	
	//Check insert object and remove object
	Object* firmino = new Object();
	WM.insertObject(firmino);
	if (WM.removeObject(firmino))
	{
		LM.writeLog("Inserting and Removing Objects worked!!");
	}
	else
		LM.writeLog("Did not work.");
		

	Object* salah = new Object();
	//Test for markfordeletion and update
	if (WM.markForDelete(salah) == -1)
	{
		LM.writeLog("Yes! Salah is only in m_update not in m_deletions");
	}
	else
		LM.writeLog("Wait...it should not work...there should be nothing in m_deletions");
		

	//ShutDown the WorldManager
	WM.shutDown();

	

	//StartUp GameManager
	if (GM.startUp())
	{
		printf("Error starting GameManager! \n");
		return 1;
	}
	GM.setGameOver(true);
	//Succesfullt started, so run the gameloop to see if it actually works
	
	DM.startUp();

	DM.drawCh(Vector(10, 5), '*', WHITE);
	DM.swapBuffers();
	Sleep(2);//sleep for 2 seconds, Window needs sleep
	
	if (GM.run())
	{
		LM.writeLog("Did it take 30 secs? Just double check");
	}
	
	
	DM.shutDown();
	//Test methods in 

	//ShutDown GameManager
	GM.shutDown();
	

	//Velocity Check
	Object p_o;
	Vector new_v = Vector(2, 2);
	Vector new_v2 = Vector();
	p_o.setDirection(new_v);
	p_o.setSpeed(2);
	p_o.setVelocity(new_v2);
	if (new_v2.equals(p_o.getVelocity()))
	{
		LM.writeLog("It does work! The velocity is 0!");
	}
	else
		LM.writeLog("It does not work. Velocity is different ");

	p_o.setNoSoft(true);
	if (p_o.getNoSoft())
	{
		LM.writeLog("They are soft!");
	}
	/*
	//Testing EventCollision
	std::vector<Object*> v_c_o = WM.returnUpdates();
	std::vector<Object*>::iterator v_c_o_li = v_c_o.begin();
	Object* ec_o = (*v_c_o_li);
	Object* ec_o2 = (*v_c_o_li);
	EventCollision e_c = EventCollision(ec_o, ec_o2, new_v);
	if (ec_o == e_c.getObject1())
	{
		LM.writeLog("Object 1 is correct");
	}
	if (ec_o2 == e_c.getObject2())
	{
		LM.writeLog("Object 2 is correct");
	}
	if (new_v.equals(e_c.getPosition()))
	{
		LM.writeLog("Position is correct");
	}
	*/

	//Testing EventMouse
	EventMouse e_m;
	e_m.setMouseAction(CLICKED);
	if (e_m.getMouseAction() == CLICKED)
		LM.writeLog("MouseActions works fine!");
	e_m.setMouseButton(Mouse::Button::LEFT);
	if (e_m.getMouseButton() == Mouse::Button::LEFT)
		LM.writeLog("Mouse Button works fine!");
	
	//Testing EventKeyBoard
	EventKeyBoard e_kb;
	e_kb.setKey(Keyboard::Key::SPACE);
	if (e_kb.getKey() == Keyboard::Key::SPACE)
		LM.writeLog("Keyboard Key works fine!");
	e_kb.setKeyboardAction(KEY_PRESSED);
	if (e_kb.getKeyboardAction() == KEY_PRESSED)
		LM.writeLog("KeyboardAction works fine!");
	if (e_kb.getType() == KEYBOARD_EVENT)
		LM.writeLog("Keyboard Type is correct!");

	LM.setFlush(true);

}
