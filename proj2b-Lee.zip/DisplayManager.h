#pragma once
#include <SFML/Graphics.hpp>
#include "Color.h"
#include "Manager.h"
#include "Vector.h"

#define DM df::DisplayManager::getInstance()

namespace df {
	enum Justification {
		LEFT_JUSTIFIED,
		CENTER_JUSTIFIED,
		RIGHT_JUSTIFIED,
	};

const int WINDOW_HORIZONTAL_PIXELS_DEFAULT = 1024;
const int WINDOW_VERTICAL_PIXELS_DEFAULT = 768;
const int WINDOW_HORIZONTAL_CHARS_DEFAULT = 80;
const int WINDOW_VERTICAL_CHARS_DEFAULT = 24;
const int WINDOW_STYLE_DEFAULT = sf::Style::Titlebar;
const sf::Color WINDOW_BACKGROUND_COLOR_DEFAULT = sf::Color::Black;
const std::string  WINDOW_TITLE_DEFAULT = "Dragonfly";
const std::string FONT_FILE_DEFAULT = "df-font.ttf";

class DisplayManager : public df::Manager
{
private:
	DisplayManager();
	DisplayManager(DisplayManager const&);
	void operator=(DisplayManager const&);
	sf::Font m_font;
	sf::RenderWindow* m_p_window;
	int m_window_horizontal_pixels;
	int m_window_vertical_pixels;
	int m_window_horizontal_chars;
	int m_window_vertical_chars;
public:
	//Get the one and only instance of the DisplayManager
	static DisplayManager& getInstance();

	//Open Graphics window, ready for text-based display.
	//Return 0 if ok, else -1
	int startUp();

	//Close graphics window.
	void shutDown();

	//Draw Character at window location (x,y) with color
	int drawCh(Vector world_pos, char ch, Color color)const;

	//Return window's horizontal maximum(in characters)
	int getHorizontal()const;

	//Return window's vertical maximum(in characters)
	int getVertical()const;

	//Return window's horizontal maximum(in pixels)
	int getHorizontalPixels()const;

	//Return window's vertical maximum(in pixels)
	int getVerticalPixels()const;

	//Render current Window Buffer
	int swapBuffers();
	
	//Return pointer to SFML graphics window
	sf::RenderWindow* getWindow() const;

	//Draw string at window location (x,y) with default color 
	//Justified left, center, or right
	//Return 0 if ok, else -1
	int drawString(Vector pos, std::string str, Justification just, Color color)const;
};

//Compute Character height, based on window size and font
float charHeight();

//compute character width, based on window size and font
float charWidth();

//convert ASCII spaces(x,y) to window pixels (x,y)
Vector spacesToPixels(Vector spaces);

//convert window pixels (x,y) to ASCII spaces (x,y)
Vector pixelsToSpaces(Vector pixels);
}

