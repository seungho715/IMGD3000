ReadMe File - Seungho(Chris) Lee

Platform is Visual Studio 2019. 
All the .h files and .cpp files are located inside the Project 2 folder, which is located in documents/Visual Studio 2019/project2/project 2.
Files: Clock, Manager, LogManager, WorldManager, GameManager, Object, Vector, Event, EventStep, and Implemented libraries(winmm and more).
To compile, you first need to build the project, which will build all the files and .o files that are necessary to run it. Then, it will run
the test, which will either put LogManager messages in the dragonfly file or display on a window screen from Visual Studio. 




With the previous classes(.h and .cpp files), I had to add several classes: 
EventCollision, which deals with collision for different objects. 
EventOut, which the player exits out of the Event.
DisplayManager, which makes the game displayable on the window screen using sf::RenderWindow
InputManager, which is used to detect the inputs from the computer and allows the Object to move
EventKeyBoard, which tracks when keyboard is pressed 
EventMouse, which tracks when mouse is moved or pressed

Run method which launches all the necessary methods to startup the game engine is fully implemented.
Clock -> getInput -> Update -> onEvent -> Draw -> SwapBuffers -> Sleep -> GameOver